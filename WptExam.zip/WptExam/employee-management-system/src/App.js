import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import AddEmployee from './AddEmployee';
import EmployeeList from './EmployeeList';

const App = () => {
  const [employees, setEmployees] = useState([]);

  const addEmployee = (employee) => {
    setEmployees([...employees, employee]);
  };

  return (
    <div className="container">
      <AddEmployee addEmployee={addEmployee} />
      <EmployeeList employees={employees} />
    </div>
  );
};

export default App;
