import React, { useState } from 'react';

const AddEmployee = ({ addEmployee }) => {
  const [employee, setEmployee] = useState({
    employeeId: '',
    employeeName: '',
    gender: '',
    dateOfBirth: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setEmployee({ ...employee, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    addEmployee(employee);
    setEmployee({
      employeeId: '',
      employeeName: '',
      gender: '',
      dateOfBirth: '',
    });
  };

  return (
    <div className="container">
      <h2>Add Employee</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Employee ID:</label>
          <input
            type="text"
            className="form-control"
            name="employeeId"
            value={employee.employeeId}
            onChange={handleChange}
          />
        </div>
        <div className="form-group">
          <label>Employee Name:</label>
          <input
            type="text"
            className="form-control"
            name="employeeName"
            value={employee.employeeName}
            onChange={handleChange}
          />
        </div>
        <div className="form-group">
          <label>Gender:</label>
          <select
            className="form-control"
            name="gender"
            value={employee.gender}
            onChange={handleChange}
          >
            <option value="">Select</option>
            <option value="male">Male</option>
            <option value="female">Female</option>
            <option value="other">Other</option>
          </select>
        </div>
        <div className="form-group">
          <label>Date of Birth:</label>
          <input
            type="date"
            className="form-control"
            name="dateOfBirth"
            value={employee.dateOfBirth}
            onChange={handleChange}
          />
        </div>
        <button type="submit" className="btn btn-primary">Add Employee</button>
      </form>
    </div>
  );
};

export default AddEmployee;
